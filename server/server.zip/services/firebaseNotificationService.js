/**
 * firebaseNotificationService.js
 *
 * KEY FIX: Background/closed app sound requires the FCM message to send
 * the EXACT channelId that is registered on the device.
 *
 * Device registers: followups_5min_en_v2, followups_due_en_v2, followups_missed_en_v2, etc.
 * Old code sent:    channelId: "followups" for ALL alerts → no custom sound in background
 * Fixed code sends: channelId: "followups_5min_en_v2" per alert type → correct sound plays
 */

const admin = require("../config/firebaseAdmin");
const { resolveAndroidChannelId } = require("../utils/notificationChannels");

// ─── Sanitize data payload (FCM requires all values to be strings) ─────────────
const sanitizeData = (data = {}) => {
    const out = {};
    for (const [key, value] of Object.entries(data || {})) {
        if (value === undefined || value === null) continue;
        if (typeof value === "string") {
            out[key] = value;
            continue;
        }
        if (typeof value === "number" || typeof value === "boolean") {
            out[key] = String(value);
            continue;
        }
        try {
            out[key] = JSON.stringify(value);
        } catch (_) {
            out[key] = String(value);
        }
    }
    return out;
};

// ─── Resolve the correct channel key for each alert type ─────────────────────
// This MUST match what notificationService.js registers on the device.
// Format: {type}_{status}_{lang}  →  resolveAndroidChannelId adds _v2 suffix
//
// Examples:
//   getAlertChannelKey("followup", 5, "en")     → "followups_5min_en"  → "followups_5min_en_v2"
//   getAlertChannelKey("phone", "due", "ta")    → "phone_due_ta"       → "phone_due_ta_v2"
//   getAlertChannelKey("email", "missed", "en") → "email_missed_en"    → "email_missed_en_v2"
const getAlertChannelKey = (
    activityType = "followup",
    status = "soon",
    lang = "en",
) => {
    const typeMap = {
        "phone call": "phone",
        phone: "phone",
        call: "phone",
        meeting: "meeting",
        email: "email",
        whatsapp: "whatsapp",
        wa: "whatsapp",
        followup: "followups",
        default: "followups",
    };
    const typeKey =
        typeMap[
            String(activityType || "")
                .trim()
                .toLowerCase()
        ] ?? "followups";
    const langSuffix =
        String(lang || "en").toLowerCase() === "ta" ? "ta" : "en";

    // Minute-based: 5, 4, 3, 2, 1
    if (typeof status === "number" || /^\d+$/.test(String(status))) {
        const m = Math.max(1, Math.min(5, Number(status)));
        return `${typeKey}_${m}min_${langSuffix}`;
    }

    const s = String(status || "soon").toLowerCase();
    if (s === "due" || s === "0") return `${typeKey}_due_${langSuffix}`;
    if (s === "missed" || s === "-1") return `${typeKey}_missed_${langSuffix}`;
    return `${typeKey}_soon_${langSuffix}`;
};

// ─── Map channel key → sound file name (no extension for Android) ─────────────
// These names must match files in android/app/src/main/res/raw/
const CHANNEL_SOUND_MAP = {
    // English — phone/followup
    followups_5min_en: "n5pmin",
    followups_4min_en: "n4pmin",
    followups_3min_en: "n3pmin",
    followups_2min_en: "n2pmin",
    followups_1min_en: "n1pmin",
    followups_due_en: "pdue",
    followups_missed_en: "pmissed",
    phone_5min_en: "n5pmin",
    phone_4min_en: "n4pmin",
    phone_3min_en: "n3pmin",
    phone_2min_en: "n2pmin",
    phone_1min_en: "n1pmin",
    phone_due_en: "pdue",
    phone_missed_en: "pmissed",
    // English — meeting
    meeting_5min_en: "m5min",
    meeting_4min_en: "m4min",
    meeting_3min_en: "m3min",
    meeting_2min_en: "m2min",
    meeting_1min_en: "m1min",
    meeting_due_en: "mdue",
    meeting_missed_en: "emissed",
    // English — email
    email_5min_en: "e5min",
    email_4min_en: "e4min",
    email_3min_en: "e3min",
    email_2min_en: "e2min",
    email_1min_en: "e1min",
    email_due_en: "edue",
    email_missed_en: "emissed",
    // English — whatsapp
    whatsapp_5min_en: "w5min",
    whatsapp_4min_en: "w4min",
    whatsapp_3min_en: "w3min",
    whatsapp_2min_en: "w2min",
    whatsapp_1min_en: "w1min",
    whatsapp_due_en: "wdue",
    whatsapp_missed_en: "wmissed",
    // Tamil — phone/followup
    followups_5min_ta: "t5min",
    followups_4min_ta: "t4min",
    followups_3min_ta: "t3min",
    followups_2min_ta: "t2min",
    followups_1min_ta: "t1min",
    followups_due_ta: "tdue",
    followups_missed_ta: "tmissed",
    phone_5min_ta: "t5min",
    phone_4min_ta: "t4min",
    phone_3min_ta: "t3min",
    phone_2min_ta: "t2min",
    phone_1min_ta: "t1min",
    phone_due_ta: "tdue",
    phone_missed_ta: "tmissed",
    // Tamil — meeting
    meeting_5min_ta: "mt5min",
    meeting_4min_ta: "mt4min",
    meeting_3min_ta: "mt3min",
    meeting_2min_ta: "mt2min",
    meeting_1min_ta: "mt1min",
    meeting_due_ta: "mtdue",
    meeting_missed_ta: "mtmissed",
    // Tamil — email
    email_5min_ta: "et5min",
    email_4min_ta: "et4min",
    email_3min_ta: "et3min",
    email_2min_ta: "et2min",
    email_1min_ta: "et1min",
    email_due_ta: "etdue",
    email_missed_ta: "etmissed",
    // Tamil — whatsapp
    whatsapp_5min_ta: "wt5min",
    whatsapp_4min_ta: "wt4min",
    whatsapp_3min_ta: "wt3min",
    whatsapp_2min_ta: "wt2min",
    whatsapp_1min_ta: "wt1min",
    whatsapp_due_ta: "wtdue",
    whatsapp_missed_ta: "wtmissed",
};

const getSoundForChannel = (channelKey) =>
    CHANNEL_SOUND_MAP[channelKey] ?? "pdue";

// ─── Remove dead FCM token ─────────────────────────────────────────────────────
const removeDeadToken = async (userId) => {
    try {
        const User = require("../models/User");
        await User.updateOne(
            { _id: userId },
            { $unset: { fcmToken: 1, fcmTokenUpdatedAt: 1 } },
        );
        console.log(`[FCM] Removed dead token for user ${userId}`);
    } catch (err) {
        console.error(
            `[FCM] Error removing dead token for ${userId}:`,
            err.message,
        );
    }
};

// ─── Main service class ───────────────────────────────────────────────────────
class FirebaseNotificationService {
    /**
     * Send a single FCM notification.
     *
     * ✅ CRITICAL FIX: channelId in android.notification MUST match the exact
     * channel registered on the device (e.g. "followups_5min_en_v2").
     * Android Oreo+ uses the channel's sound — the FCM message sound field is ignored.
     */
    async sendNotification(fcmToken, payload, userId = null) {
        // ✅ FIX: Resolve exact channel key and android channel ID
        const channelKey =
            payload.channelKey || payload.channelId || "followups";
        const androidChannelId = resolveAndroidChannelId(channelKey);
        const soundName = getSoundForChannel(channelKey);

        // Log notification being prepared
        console.log(`[FCM] Preparing notification:`, {
            userId: userId ? `${userId.substring(0, 8)}...` : "anonymous",
            type: payload.type || "unknown",
            channelKey,
            androidChannelId,
            soundName,
            timestamp: new Date().toISOString(),
        });

        // Data payload — all strings, always delivered in all app states
        const dataPayload = sanitizeData({
            type: payload.type || "followup-reminder",
            soundName,
            channelKey,
            androidChannelId,
            activityType: payload.activityType || "",
            voiceLang: payload.voiceLang || "en",
            audioType: payload.audioType || "pre_recorded",
            audioUrl: payload.audioUrl || soundName,
            ttsText: payload.ttsText || "",
            minutesLeft: String(payload.minutesLeft ?? ""),
            timestamp: String(Date.now()),
            ...payload.data,
        });

        const message = {
            token: fcmToken,

            // Notification block — required for OS to show in tray when app is killed
            notification: {
                title: payload.title,
                body: payload.body,
            },

            // Data block — always delivered regardless of app state
            data: dataPayload,

            // ✅ Android config
            android: {
                priority: "high", // Required for killed-app delivery
                ttl: 3600 * 1000, // 1 hour — discard stale reminders

                notification: {
                    title: payload.title,
                    body: payload.body,

                    // ✅ CRITICAL FIX: Exact channel ID registered on device
                    // This triggers the correct WAV sound in background/closed app
                    channelId: androidChannelId,

                    notificationPriority: "PRIORITY_MAX",
                    // ✅ Do NOT set defaultSound:true — it overrides the channel sound
                    color: payload.color || "#2563EB",
                    tag: `followup_${channelKey}`,
                    visibility: "PUBLIC",
                    sticky: false,
                },
            },

            // ✅ iOS config
            apns: {
                headers: {
                    "apns-priority": "10",
                    "apns-push-type": "alert",
                    "apns-expiration": String(
                        Math.floor(Date.now() / 1000) + 3600,
                    ),
                },
                payload: {
                    aps: {
                        alert: { title: payload.title, body: payload.body },
                        // ✅ iOS: sound file WITH .caf extension in app bundle
                        sound: `${soundName}.caf`,
                        badge: 1,
                        "content-available": 1, // Background wake
                        "mutable-content": 1, // Allow notification service extension
                    },
                },
            },
        };

        try {
            const response = await admin.messaging().send(message);
            console.log(`[FCM] ✅ Sent:`, {
                userId: userId
                    ? `${String(userId).substring(0, 8)}...`
                    : "anonymous",
                type: payload.type || "unknown",
                messageId: String(response).substring(0, 20),
                channel: androidChannelId,
                sound: soundName,
            });
            return { success: true, messageId: response };
        } catch (error) {
            const deadCodes = [
                "messaging/invalid-registration-token",
                "messaging/registration-token-not-registered",
                "messaging/third-party-auth-error",
            ];
            if (deadCodes.includes(error.code)) {
                console.error(`[FCM] ❌ Dead token (${error.code}):`, {
                    userId: userId
                        ? `${String(userId).substring(0, 8)}...`
                        : "anonymous",
                    type: payload.type || "unknown",
                    error: error.message,
                });
                if (userId) await removeDeadToken(userId);
                return {
                    success: false,
                    error: "Invalid token (removed)",
                    deadToken: true,
                };
            }
            console.error(`[FCM] ❌ Send error:`, {
                userId: userId
                    ? `${String(userId).substring(0, 8)}...`
                    : "anonymous",
                type: payload.type || "unknown",
                error: error.message,
                code: error.code,
            });
            return { success: false, error: error.message };
        }
    }

    // ── Batch send ─────────────────────────────────────────────────────────────
    async sendToUsers(userIds, payload) {
        const User = require("../models/User");
        const users = await User.find({
            _id: { $in: userIds },
            fcmToken: { $exists: true, $ne: null },
        }).lean();

        if (users.length === 0)
            return { total: 0, successful: 0, failed: 0, deadTokensRemoved: 0 };

        const results = await Promise.allSettled(
            users.map((user) =>
                this.sendNotification(user.fcmToken, payload, user._id),
            ),
        );

        const deadTokenUserIds = [];
        results.forEach((result, i) => {
            if (result.status === "fulfilled" && result.value?.deadToken)
                deadTokenUserIds.push(users[i]._id);
        });
        deadTokenUserIds.forEach((uid) => removeDeadToken(uid).catch(() => {}));

        return {
            total: users.length,
            successful: results.filter(
                (r) => r.status === "fulfilled" && r.value?.success,
            ).length,
            failed: results.filter(
                (r) => r.status === "rejected" || !r.value?.success,
            ).length,
            deadTokensRemoved: deadTokenUserIds.length,
        };
    }

    // ── ✅ FIXED: Timed reminders with correct per-minute channel IDs ──────────
    /**
     * @param {string} userId
     * @param {object} followUpData
     * @param {number} minutesLeft   5|4|3|2|1 = soon, 0 = due now, -1 = missed
     * @param {string} activityType  phone|meeting|email|whatsapp|followup
     * @param {string} voiceLang     en|ta
     */
    async sendFollowUpReminder(
        userId,
        followUpData,
        minutesLeft = 5,
        activityType = "followup",
        voiceLang = "en",
    ) {
        const User = require("../models/User");
        const user = await User.findById(userId).lean();
        if (!user?.fcmToken)
            return { success: false, error: "FCM token not found" };

        const lang =
            voiceLang || user.notificationPreferences?.voiceLang || "en";

        let title, body, status, type;

        if (minutesLeft < 0) {
            status = "missed";
            type = "followup-missed";
            title = "⚠️ Missed Follow-up";
            body = `You missed a follow-up${followUpData?.name ? ` with ${followUpData.name}` : ""}. Reschedule now.`;
        } else if (minutesLeft === 0) {
            status = "due";
            type = "followup-due";
            title = "🔔 Follow-up Due Now";
            body = `Time for your follow-up${followUpData?.name ? ` with ${followUpData.name}` : ""}!`;
        } else {
            status = minutesLeft;
            type = "followup-soon"; // numeric → getAlertChannelKey handles it
            title = `⏰ Follow-up in ${minutesLeft} min`;
            body = `Upcoming follow-up${followUpData?.name ? ` with ${followUpData.name}` : ""} in ${minutesLeft} minute${minutesLeft > 1 ? "s" : ""}.`;
        }

        // ✅ CRITICAL FIX: Use exact channel key matching device registration
        const channelKey = getAlertChannelKey(activityType, status, lang);

        console.log(
            `[FCM] sendFollowUpReminder: minutesLeft=${minutesLeft}, activity=${activityType}, lang=${lang}, channelKey=${channelKey} → ${resolveAndroidChannelId(channelKey)}`,
        );

        return this.sendNotification(
            user.fcmToken,
            {
                title,
                body,
                type,
                activityType,
                voiceLang: lang,
                audioType: "pre_recorded",
                minutesLeft,
                channelKey, // ✅ Pass resolved channel key, not generic "followups"
                color: minutesLeft < 0 ? "#FF3B5C" : "#0EA5E9",
                data: {
                    ...followUpData,
                    minutesLeft: String(minutesLeft),
                    activityType,
                    voiceLang: lang,
                },
            },
            user._id,
        );
    }

    // ── ✅ FIXED: Activity-type specific reminders ─────────────────────────────
    async sendActivityReminder(
        userId,
        activityType,
        followUpData,
        minutesLeft = 5,
        voiceLang = "en",
    ) {
        const User = require("../models/User");
        const user = await User.findById(userId).lean();
        if (!user?.fcmToken)
            return { success: false, error: "FCM token not found" };

        const lang =
            voiceLang || user.notificationPreferences?.voiceLang || "en";
        const status =
            minutesLeft < 0
                ? "missed"
                : minutesLeft === 0
                  ? "due"
                  : minutesLeft;
        const type =
            minutesLeft < 0
                ? "followup-missed"
                : minutesLeft === 0
                  ? "followup-due"
                  : "followup-soon";

        const typeLabels = {
            phone: "📞 Phone Call",
            meeting: "🤝 Meeting",
            email: "📧 Email",
            whatsapp: "💬 WhatsApp",
            followup: "📋 Follow-up",
        };
        const typeLabel = typeLabels[activityType] || "📋 Follow-up";

        // ✅ CRITICAL FIX: Exact channel key
        const channelKey = getAlertChannelKey(activityType, status, lang);

        return this.sendNotification(
            user.fcmToken,
            {
                title: `${typeLabel} Reminder`,
                body:
                    minutesLeft > 0
                        ? `${typeLabel} with ${followUpData?.name || "lead"} in ${minutesLeft} min`
                        : `${typeLabel} with ${followUpData?.name || "lead"} is due now!`,
                type,
                activityType,
                voiceLang: lang,
                audioType: "pre_recorded",
                minutesLeft,
                channelKey, // ✅ Exact channel key
                color: minutesLeft < 0 ? "#FF3B5C" : "#0EA5E9",
                data: {
                    ...followUpData,
                    minutesLeft: String(minutesLeft),
                    activityType,
                    voiceLang: lang,
                },
            },
            user._id,
        );
    }

    // ── Urgent (overdue) reminder ──────────────────────────────────────────────
    async sendUrgentReminder(userId, followUpData) {
        const User = require("../models/User");
        const user = await User.findById(userId).lean();
        if (!user?.fcmToken)
            return { success: false, error: "FCM token not found" };

        const lang = user.notificationPreferences?.voiceLang || "en";
        // ✅ Use missed channel for urgent
        const channelKey = getAlertChannelKey("followup", "missed", lang);

        return this.sendNotification(
            user.fcmToken,
            {
                title: "🚨 Overdue Follow-ups!",
                body: "You have overdue follow-ups. Complete them now!",
                type: "urgent",
                activityType: "followup",
                voiceLang: lang,
                channelKey,
                color: "#FF3B5C",
                urgent: true,
                data: followUpData,
            },
            user._id,
        );
    }

    // ── Enquiry alert ──────────────────────────────────────────────────────────
    async sendEnquiryAlert(userId, enquiryData) {
        const User = require("../models/User");
        const user = await User.findById(userId).lean();
        if (!user?.fcmToken)
            return { success: false, error: "FCM token not found" };

        return this.sendNotification(
            user.fcmToken,
            {
                title: "📌 New Enquiry",
                body: `New enquiry from ${enquiryData.name}${enquiryData.product ? ` for ${enquiryData.product}` : ""}`,
                type: "new-enquiry",
                activityType: "followup",
                channelKey: "enquiries",
                color: "#16A34A",
                data: enquiryData,
            },
            user._id,
        );
    }

    // ── Broadcast ──────────────────────────────────────────────────────────────
    async broadcastNotification(title, body, data = {}) {
        const User = require("../models/User");
        const users = await User.find({
            fcmToken: { $exists: true, $ne: null },
        }).lean();
        if (users.length === 0) return { message: "No users with FCM tokens" };

        const results = await Promise.allSettled(
            users.map((user) =>
                this.sendNotification(
                    user.fcmToken,
                    {
                        title,
                        body,
                        type: "broadcast",
                        activityType: "followup",
                        channelKey: "default",
                        data,
                    },
                    user._id,
                ),
            ),
        );

        return {
            success: true,
            sent: results.filter(
                (r) => r.status === "fulfilled" && r.value?.success,
            ).length,
            failed: results.filter(
                (r) => r.status === "rejected" || !r.value?.success,
            ).length,
        };
    }
}

module.exports = new FirebaseNotificationService();
